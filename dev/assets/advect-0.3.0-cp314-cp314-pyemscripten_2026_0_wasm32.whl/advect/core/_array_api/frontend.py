# ruff: noqa: ANN401, FBT001
# ANN401: the Array API protocol is intentionally backend-agnostic.
# FBT001: __array__ follows NumPy's positional copy protocol.
"""Backend-neutral tracing for Python Array API implementations.

This frontend is deliberately small and provider-agnostic.  It recognizes an
Array API namespace from ``__array_namespace__``, evaluates operations through
that namespace, and records canonical ``array.*`` nodes.  NumPy has a richer,
separate frontend and is intentionally excluded here.

Operation binding remains separate from concrete provider execution so staging
can reuse the canonical call schema.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from functools import partial
from typing import TYPE_CHECKING, Any, ClassVar, cast

from advect.core._abstract_domains import operation_semantics
from advect.core._abstract_helpers import (
    ABSTRACT_NAMESPACE_NAME,
    PYTHON_SCALAR_TYPES,
    accumulation_dtype,
    broadcast_shape as _broadcast_shape,
    dtype_name,
    normalize_axis as _normalize_axis,
)
from advect.core._array_api.profiles import (
    LATEST_ARRAY_API_VERSION,
    materialize_array_api_profile,
)
from advect.core._array_api.providers import (
    _get_array_namespace,
    _get_backend_key_from_namespace,
    _namespace_serves,
)
from advect.core._array_api.results import restore_array_api_result
from advect.core._array_api.signatures import (
    OFFICIAL_SIGNATURES,
    official_parameter_names,
    official_parameters,
    official_positional_parameter_names,
)
from advect.core._array_family_ops import (
    ARRAY_API_TO_CANONICAL,
    _canonical_array_family_op_name,
)
from advect.core._array_protocol_helpers import (
    PYTHON_ATTRIBUTE_OPS,
    literal_is_weak,
    materialize_weak_scalar_operands,
    python_operator,
    select_item,
    weak_scalar_runtime_value,
)
from advect.core._context import (
    _get_active_array_api_version,
    _get_active_recorder,
    _is_recorder_in_active_trace_stack,
    _select_deepest_active_recorder,
    get_source_location,
    is_debug,
)
from advect.core._diagnostics import summarize_value
from advect.core._errors import (
    EscapedTracerError,
    MutationError,
    TracingError,
    _array_conversion_error,
)
from advect.core._protocols import _is_traced, _snapshot_traced
from advect.core._registry import get_registry

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from advect.core._native import DynamicTape

__all__ = [
    "ArrayAPICallBinding",
    "ArrayAPINamespace",
    "ArrayAPITracer",
    "bind_array_api_call",
    "lower_array_api_call",
]

_MIN_MATRIX_RANK = 2
_EXPAND_DIMS_POSITIONAL_ARITY = 2

_ARRAY_API_COMPOSITE_OPERANDS = {
    "broadcast_arrays": ("arrays",),
    "linalg.matrix_power": ("x",),
    "linalg.matrix_rank": ("x", "rtol"),
    "meshgrid": ("arrays",),
    "nonzero": ("x",),
    "unique_all": ("x",),
    "unique_counts": ("x",),
    "unique_inverse": ("x",),
    "unique_values": ("x",),
    "unstack": ("x",),
}
_ARRAY_API_COMPOSITES = frozenset(_ARRAY_API_COMPOSITE_OPERANDS)
_STAGED_ARRAY_API_COMPOSITES = frozenset(
    {
        "broadcast_arrays",
        "linalg.matrix_power",
        "linalg.matrix_rank",
        "meshgrid",
        "unstack",
    }
)
_DYNAMIC_ARRAY_API_COMPOSITES = _ARRAY_API_COMPOSITES - _STAGED_ARRAY_API_COMPOSITES
_NONDIFFERENTIABLE_ARRAY_API_COMPOSITES = frozenset(
    {
        "linalg.matrix_rank",
        "nonzero",
    }
)


@dataclass(frozen=True, slots=True)
class _FunctionSpec:
    op: str
    operands: tuple[str, ...]
    positional: tuple[str, ...]
    sequence_operands: frozenset[str] = frozenset()
    optional_operands: frozenset[str] = frozenset()


_ARRAY_API_META_FUNCTIONS = frozenset({"can_cast", "finfo", "iinfo", "isdtype", "result_type"})


def _function_specs() -> dict[str, _FunctionSpec]:
    unsupported = {
        "from_dlpack",
        *_ARRAY_API_COMPOSITES,
    }
    operand_exceptions = {
        "clip": ("x", "min", "max"),
        "full": ("fill_value",),
        "linalg.pinv": ("x", "rtol"),
    }
    schemas = {name: schema for name, schema, _evaluator in operation_semantics()}
    specs: dict[str, _FunctionSpec] = {}
    for path in OFFICIAL_SIGNATURES:
        if path in unsupported or path in _ARRAY_API_META_FUNCTIONS:
            continue
        op = (
            "array.astype"
            if path == "asarray"
            else _canonical_array_family_op_name(ARRAY_API_TO_CANONICAL.get(path, path))
        )
        schema = schemas[op]
        operands = operand_exceptions.get(path, official_parameter_names(path)[: schema.operands])
        specs[path] = _FunctionSpec(
            op=op,
            operands=operands,
            positional=official_positional_parameter_names(path),
            sequence_operands=(frozenset(operands[:1]) if schema.sequence_operand else frozenset()),
            optional_operands=frozenset(
                parameter.name
                for parameter in official_parameters(path)
                if parameter.has_default and parameter.name in operands
            ),
        )
    return specs


_FUNCTION_SPECS = _function_specs()

# Private provider extensions used while tracing derivative rules. Keeping
# these out of `_FUNCTION_SPECS` avoids advertising them as Array API surface
# or requiring providers which implement only the standard to expose them.
_INTERNAL_FUNCTION_SPECS: dict[str, _FunctionSpec] = {
    # Derivative rules use NumPy's historical spellings even when the selected
    # Array API revision predates the standard cumulative-function names.
    "cumprod": _FUNCTION_SPECS["cumulative_prod"],
    "cumsum": _FUNCTION_SPECS["cumulative_sum"],
    "ldexp": _FunctionSpec("array_ext.ldexp", ("x", "exponent"), ("x", "exponent")),
    "linalg.eig": _FunctionSpec("array_ext.linalg.eig", ("x",), ("x",)),
}
_BINARY_ARITY = 2
# Official static parameters recorded under another node attribute name.
# Frontend-private ``_advect_*`` attributes bypass abstract attribute schemas.
_RENAMED_PARAMETERS = {"device": "_advect_device", "repetitions": "reps"}
_ACCUMULATION_FUNCTIONS = frozenset({"prod", "sum"})
# Python operator stems and the standard functions both tracer classes call.
# Arithmetic and bitwise operators also install reflected methods; Python
# reflects a comparison through the other operand's mirrored method.
_ARITHMETIC_OPERATORS = {
    "add": "add",
    "sub": "subtract",
    "mul": "multiply",
    "truediv": "divide",
    "floordiv": "floor_divide",
    "mod": "remainder",
    "pow": "pow",
    "matmul": "matmul",
    "and": "bitwise_and",
    "or": "bitwise_or",
    "xor": "bitwise_xor",
    "lshift": "bitwise_left_shift",
    "rshift": "bitwise_right_shift",
}
_COMPARISON_OPERATORS = {
    "lt": "less",
    "le": "less_equal",
    "gt": "greater",
    "ge": "greater_equal",
    "eq": "equal",
    "ne": "not_equal",
}


@dataclass(frozen=True, slots=True)
class ArrayAPICallBinding:
    """Backend-independent result of binding one supported Array API call."""

    op: str
    operands: tuple[Any, ...]
    attrs: Mapping[str, Any]
    num_outputs: int


def _bind_array_api_parameters(
    path: str,
    spec: _FunctionSpec,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> dict[str, Any]:
    if len(args) > len(spec.positional):
        msg = (
            f"Array API {path}() takes {len(spec.positional)} positional arguments "
            f"but {len(args)} were given"
        )
        raise TypeError(msg)
    bound = dict(zip(spec.positional, args, strict=False))
    for name, value in kwargs.items():
        if name in bound:
            msg = f"Array API {path}() received {name!r} twice"
            raise TypeError(msg)
        bound[name] = value
    return bound


def _collect_array_api_operands(
    path: str,
    spec: _FunctionSpec,
    attrs: dict[str, Any],
) -> list[Any]:
    """Move bound operands out of ``attrs`` in the canonical schema order."""
    operands: list[Any] = []
    for name in spec.operands:
        if name not in attrs:
            if name not in spec.optional_operands:
                msg = f"Array API {path}() missing required argument {name!r}"
                raise TypeError(msg)
            continue
        value = attrs.pop(name)
        if path == "clip" and name in {"min", "max"}:
            attrs[f"_advect_clip_{name}_is_input"] = value is not None
            if value is None:
                continue
        if path == "linalg.pinv" and name == "rtol":
            attrs["_advect_pinv_tolerance"] = "rtol" if value is not None else None
            if value is None:
                continue
        if name not in spec.sequence_operands:
            operands.append(value)
            continue
        if not isinstance(value, (tuple, list)):
            msg = f"Array API {path}() expects {name!r} to be a list or tuple"
            raise TypeError(msg)
        if not value:
            msg = f"Array API {path}() requires a non-empty list or tuple of arrays"
            raise ValueError(msg)
        operands.extend(value)
    return operands


def _normalize_array_api_attrs(
    path: str,
    attrs: dict[str, Any],
    operands: list[Any],
) -> None:
    if path == "asarray":
        attrs["_advect_array_api_asarray"] = True
    for name, attribute in _RENAMED_PARAMETERS.items():
        value = attrs.pop(name, None)
        if value is not None:
            attrs[attribute] = str(value) if name == "device" else value
    if path == "clip":
        attrs.setdefault("_advect_clip_min_is_input", False)
        attrs.setdefault("_advect_clip_max_is_input", False)
    if path == "sort":
        attrs.setdefault("descending", False)
        attrs.setdefault("stable", True)
    if path == "repeat" and getattr(_unwrap(attrs.get("repeats")), "ndim", 0) != 0:
        # The support inventory declares array-valued repeats untraceable;
        # reject them here, as the NumPy frontend does, not in the transpose.
        msg = "repeat supports only scalar repeats during tracing"
        raise TracingError(msg)
    if path in {"linalg.diagonal", "linalg.trace"}:
        attrs["axis1"] = -2
        attrs["axis2"] = -1
    if not path.endswith("matrix_transpose") or not operands:
        return
    shape = getattr(operands[0], "shape", ())
    rank = len(shape)
    if rank < _MIN_MATRIX_RANK:
        msg = "matrix_transpose requires an array with at least two dimensions"
        raise ValueError(msg)
    axes = list(range(rank))
    axes[-2], axes[-1] = axes[-1], axes[-2]
    attrs["axes"] = tuple(axes)


def bind_array_api_call(
    path: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> ArrayAPICallBinding:
    """Classify data operands and static attributes without executing the call."""
    spec = _FUNCTION_SPECS.get(path) or _INTERNAL_FUNCTION_SPECS.get(path)
    if spec is None:
        msg = (
            f"Array API function {path!r} is not traceable yet. "
            "Define it as an Advect primitive or use supported Array API operations."
        )
        raise NotImplementedError(msg)

    attrs = _bind_array_api_parameters(path, spec, args, kwargs)
    operands = _collect_array_api_operands(path, spec, attrs)
    _normalize_array_api_attrs(path, attrs, operands)

    return ArrayAPICallBinding(
        op=spec.op,
        operands=tuple(operands),
        attrs=attrs,
        num_outputs=get_registry().get(spec.op).num_outputs,
    )


def _normalize_provider_call(
    path: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> tuple[tuple[Any, ...], dict[str, Any]]:
    """Adapt observed provider signatures to the selected official contract."""
    if path != "expand_dims" or len(args) != _EXPAND_DIMS_POSITIONAL_ARITY or "axis" in kwargs:
        return args, kwargs
    # All supported specifications accept ``axis`` positionally, while the
    # array-api-strict reference provider currently exposes it keyword-only.
    options = dict(kwargs)
    options["axis"] = args[1]
    return args[:1], options


def _normalize_accumulation_dtype(
    path: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    *,
    namespace: Any,
    array_api_version: str,
) -> dict[str, Any]:
    """Apply the selected revision's default accumulation dtype."""
    if path not in _ACCUMULATION_FUNCTIONS or not args or kwargs.get("dtype") is not None:
        return kwargs
    source_dtype = args[0].dtype
    target_name = accumulation_dtype(
        source_dtype,
        array_api_version=array_api_version,
    )
    if target_name == dtype_name(source_dtype):
        return kwargs
    target_dtype = getattr(namespace, target_name, None)
    if target_dtype is None:
        msg = f"The runtime array namespace does not provide dtype {target_name!r}"
        raise TypeError(msg)
    normalized = dict(kwargs)
    normalized["dtype"] = target_dtype
    return normalized


def _selected_array_api_version() -> str:
    return _get_active_array_api_version() or LATEST_ARRAY_API_VERSION


def _raw_namespace(value: Any, *, api_version: str | None = None) -> Any | None:
    selected = _selected_array_api_version() if api_version is None else api_version
    resolved = _get_array_namespace(value, api_version=selected)
    if resolved is not None:
        return resolved
    namespace_function = getattr(value, "__array_namespace__", None)
    if not callable(namespace_function):
        return None
    try:
        # A default namespace still lets the acceptance predicate emit a
        # precise version error for providers that cannot serve the pin.
        return namespace_function()
    except Exception:  # noqa: BLE001 - backend discovery must be non-invasive
        return None


def _accepts_array_api(value: Any) -> bool:
    if isinstance(value, ArrayAPITracer):
        return True
    if not hasattr(value, "shape") or not hasattr(value, "dtype"):
        return False
    selected = _selected_array_api_version()
    namespace = _raw_namespace(value, api_version=selected)
    if namespace is None:
        return False
    # NumPy and its nested tracers retain their richer first-class frontend.
    backend = _get_backend_key_from_namespace(namespace)
    if backend is not None and backend.split(".", 1)[0] == "numpy":
        return False
    # Nested transforms legitimately present an enclosing tracer as the
    # "concrete" value of an inner trace. Its namespace has already been
    # validated by the enclosing frontend and intentionally exposes only the
    # operations admitted by that trace.
    if callable(getattr(value, "_advect_snapshot", None)):
        return True
    version = getattr(namespace, "__array_api_version__", None)
    namespace_info = getattr(namespace, "__array_namespace_info__", None)
    asarray = getattr(namespace, "asarray", None)
    if isinstance(version, str) and callable(namespace_info) and callable(asarray):
        if not _namespace_serves(namespace, selected):
            msg = f"Advect selected Array API {selected}; the input provider exposes {version}"
            raise TypeError(msg)
    elif not _namespace_serves(namespace, selected):
        return False
    return backend is not None


def _handle_array_api_input(
    value: Any,
    name: str | None = None,
    *,
    active: bool = True,
) -> ArrayAPITracer:
    recorder = _get_active_recorder()
    if recorder is None:
        msg = "Array API inputs require an active trace"
        raise RuntimeError(msg)
    selected = _selected_array_api_version()
    namespace = _raw_namespace(value, api_version=selected)
    if namespace is None:
        msg = f"{type(value).__name__} no longer exposes an Array API namespace"
        raise TypeError(msg)
    if not callable(getattr(value, "_advect_snapshot", None)) and not _namespace_serves(
        namespace, selected
    ):
        version = getattr(namespace, "__array_api_version__", None)
        msg = f"Advect selected Array API {selected}; the input provider exposes {version!r}"
        raise TypeError(msg)
    node_id = recorder.record_input(
        value,
        tuple(int(dimension) for dimension in value.shape),
        value.dtype,
        name=name,
        active=active,
    )
    return ArrayAPITracer(
        value,
        node_id,
        recorder,
        namespace=namespace,
        array_api_version=selected,
        owned=False,
    )


def _wrap_traced(value: Any, *, node_id: int, recorder: DynamicTape) -> ArrayAPITracer:
    selected = _selected_array_api_version()
    namespace = _raw_namespace(value, api_version=selected)
    if namespace is None:
        msg = "A traced Array API result no longer exposes its namespace"
        raise TypeError(msg)
    return ArrayAPITracer(
        value,
        node_id,
        recorder,
        namespace=namespace,
        array_api_version=selected,
    )


def _copy_array_value(value: Any, namespace: Any) -> Any:
    """Copy one provider value without changing its trace identity."""
    copy_value = getattr(value, "copy", None)
    if callable(copy_value):
        return copy_value()
    asarray = getattr(namespace, "asarray", None)
    if not callable(asarray):
        msg = "The Array API provider does not implement asarray(copy=True)"
        raise TypeError(msg)
    return asarray(value, copy=True)


def _unwrap(value: Any) -> Any:
    if isinstance(value, ArrayAPITracer):
        payload = _unwrap(value._advect_snapshot()[1])  # noqa: SLF001 - same frontend
        return weak_scalar_runtime_value(value, payload)
    if isinstance(value, tuple):
        return tuple(_unwrap(item) for item in value)
    if isinstance(value, list):
        return [_unwrap(item) for item in value]
    if isinstance(value, dict):
        return {key: _unwrap(item) for key, item in value.items()}
    return value


def _as_array_api_nested(value: Any, namespace: ArrayAPINamespace) -> Any:
    """Present other frontends' tracers in a dynamic trace inside a stage as Array API tracers.

    Inside a stage, a dynamic trace wraps staged values as Array API tracers,
    and a NumPy function of one returns the NumPy frontend's tracer of the same
    node, as a primitive call on constants returns one of a constant node. An
    Array API function then reads that node through this frontend.
    """
    if isinstance(value, tuple):
        return tuple(_as_array_api_nested(item, namespace) for item in value)
    if isinstance(value, list):
        return [_as_array_api_nested(item, namespace) for item in value]
    if isinstance(value, dict):
        return {key: _as_array_api_nested(item, namespace) for key, item in value.items()}
    if getattr(type(value), "__advect_frontend__", None) is None:
        return value
    node_id, payload = _snapshot_traced(value)
    # A tracer of an enclosing dynamic trace's value stays with its frontend.
    if _is_traced(payload) and not bool(getattr(type(payload), "__advect_abstract_array__", False)):
        return value
    return ArrayAPITracer(
        payload,
        node_id,
        value.recorder,
        namespace=namespace.raw_namespace,
        array_api_version=namespace._array_api_version,  # noqa: SLF001 - same frontend
        owned=False,
    )


def _tracer_recorders(value: Any) -> tuple[DynamicTape, ...]:
    recorders: list[DynamicTape] = []
    current = value
    while isinstance(current, ArrayAPITracer):
        current._require_active_recorder()  # noqa: SLF001 - internal chain validation
        recorders.append(current.recorder)
        current = _snapshot_traced(current)[1]
    return tuple(recorders)


def _operand_for_recorder(
    operand: Any,
    *,
    recorder: DynamicTape,
) -> tuple[int | None, Any]:
    original = operand
    current = operand
    while isinstance(current, ArrayAPITracer):
        if current.recorder is recorder:
            # Callers pass an active recorder, so this SSA value is live.
            return current._node_id, weak_scalar_runtime_value(current, current._value)  # noqa: SLF001
        current = current._advect_snapshot()[1]  # noqa: SLF001 - same frontend

    if isinstance(original, ArrayAPITracer):
        original_level, _frame_id = original.recorder.runtime_trace_identity()
        recorder_level, _frame_id = recorder.runtime_trace_identity()
        if (
            original_level is not None
            and recorder_level is not None
            and original_level < recorder_level
        ):
            return None, original
        return None, _unwrap(original)

    namespace = _raw_namespace(operand)
    if (
        namespace is not None and hasattr(operand, "shape") and hasattr(operand, "dtype")
    ) or isinstance(operand, (bool, int, float, complex)):
        return None, operand
    msg = f"Unsupported dynamic Array API operand of type {type(operand).__name__}"
    raise TypeError(msg)


def _record_array_api_operation(
    *,
    recorder: DynamicTape,
    op: str,
    operands: tuple[Any, ...],
    value: Any,
    attrs: dict[str, Any],
    shape: tuple[int, ...],
    dtype: Any,
    weak: bool,
) -> int:
    projected = tuple(_operand_for_recorder(operand, recorder=recorder) for operand in operands)
    parents = tuple(node_id for node_id, _value in projected if node_id is not None)
    literals = tuple(item for node_id, item in projected if node_id is None)
    return recorder.record_operation(
        op,
        parents,
        value,
        attrs,
        shape,
        dtype,
        input_positions=(
            tuple(
                position for position, (node_id, _) in enumerate(projected) if node_id is not None
            )
            if literals
            else None
        ),
        literals=literals,
        weak=weak,
        source_location=get_source_location(),
    )


def _normalize_array_api_outputs(
    path: str,
    result: Any,
    *,
    num_outputs: int,
) -> tuple[tuple[Any, ...], tuple[tuple[tuple[int, ...], Any], ...]]:
    """Validate one declared result contract and normalize public tuples."""
    if num_outputs == 1:
        outputs = (result,)
    else:
        if not isinstance(result, tuple):
            msg = (
                f"Array API function {path!r} must return a tuple of {num_outputs} "
                f"outputs, got {type(result).__name__}"
            )
            raise TypeError(msg)
        outputs = tuple(result)
        if len(outputs) != num_outputs:
            msg = (
                f"Array API function {path!r} returned {len(outputs)} outputs, "
                f"expected {num_outputs}"
            )
            raise ValueError(msg)

    metadata: list[tuple[tuple[int, ...], Any]] = []
    for index, output in enumerate(outputs):
        if not hasattr(output, "shape") or not hasattr(output, "dtype"):
            suffix = "" if num_outputs == 1 else f" at output {index}"
            msg = (
                f"Array API function {path!r} returned "
                f"{type(output).__name__}{suffix}; data-dependent-shape results "
                "are not traceable"
            )
            raise NotImplementedError(msg)
        metadata.append(
            (
                tuple(int(dimension) for dimension in output.shape),
                output.dtype,
            )
        )
    return outputs, tuple(metadata)


def _record_array_api_result(
    *,
    recorder: DynamicTape,
    binding: ArrayAPICallBinding,
    values: tuple[Any, ...],
    attrs: dict[str, Any],
    metadata: tuple[tuple[tuple[int, ...], Any], ...],
    namespace: Any,
    array_api_version: str,
    weak: bool,
) -> Any:
    """Record one fixed-arity result and return recorder-local wrappers.

    ``weak`` marks a single rank-zero result as a weak scalar (NEP 50).
    """
    parent_value: Any = values[0] if len(values) == 1 else tuple(values)
    first_shape, first_dtype = metadata[0]
    parent_id = _record_array_api_operation(
        recorder=recorder,
        op=binding.op,
        operands=binding.operands,
        value=parent_value,
        attrs=attrs,
        shape=first_shape,
        dtype=first_dtype,
        weak=weak,
    )
    if len(values) == 1:
        return ArrayAPITracer(
            parent_value,
            parent_id,
            recorder,
            namespace=namespace,
            array_api_version=array_api_version,
        )

    outputs: list[ArrayAPITracer] = []
    for index, (value, (shape, dtype)) in enumerate(zip(values, metadata, strict=True)):
        output_id = recorder.record_operation(
            "advect.getoutput",
            (parent_id,),
            value,
            {"index": index, "num_outputs": len(values)},
            shape,
            dtype,
        )
        outputs.append(
            ArrayAPITracer(
                value,
                output_id,
                recorder,
                namespace=namespace,
                array_api_version=array_api_version,
            )
        )
    return tuple(outputs)


def _recorder_trace_level(recorder: DynamicTape) -> int:
    level, _frame_id = recorder.runtime_trace_identity()
    if level is None:
        msg = "Array API operation recorder is not bound to an active trace level"
        raise TracingError(msg)
    return level


def _recording_targets(tracers: list[ArrayAPITracer]) -> tuple[DynamicTape, ...]:
    """Return every recorder one operation records into, outermost first.

    Callers validate each tracer's own recorder. Operands owned by one
    recorder with concrete payloads, the common case, need no trace-level
    ordering; nested tracers also record into each enclosing recorder.
    """
    recorder = tracers[0].recorder
    if all(
        tracer.recorder is recorder and not isinstance(tracer._value, ArrayAPITracer)  # noqa: SLF001
        for tracer in tracers
    ):
        return (recorder,)
    recorder = cast(
        "DynamicTape",
        _select_deepest_active_recorder(tracer.recorder for tracer in tracers),
    )
    recorder_chain = {
        nested_recorder for tracer in tracers for nested_recorder in _tracer_recorders(tracer)
    }
    target_level = _recorder_trace_level(recorder)
    enclosing_recorders = sorted(
        (
            nested_recorder
            for nested_recorder in recorder_chain
            if nested_recorder is not recorder
            and _recorder_trace_level(nested_recorder) < target_level
        ),
        key=_recorder_trace_level,
    )
    return (*enclosing_recorders, recorder)


def _array_api_tracers(value: Any) -> tuple[ArrayAPITracer, ...]:
    if isinstance(value, ArrayAPITracer):
        return (value,)
    if isinstance(value, (tuple, list)):
        return tuple(tracer for item in value for tracer in _array_api_tracers(item))
    if isinstance(value, dict):
        return tuple(tracer for item in value.values() for tracer in _array_api_tracers(item))
    return ()


def _same_namespace(left: Any, right: Any) -> bool:
    if left is right:
        return True
    return _get_backend_key_from_namespace(left) == _get_backend_key_from_namespace(right)


def _matrix_power_composite(namespace: Any, matrix: Any, exponent: object) -> Any:
    if isinstance(exponent, bool) or not isinstance(exponent, int):
        message = "matrix_power exponent must be a static integer"
        raise TypeError(message)
    shape = tuple(int(size) for size in matrix.shape)
    if len(shape) < _MIN_MATRIX_RANK or shape[-2] != shape[-1]:
        message = "matrix_power requires square matrices"
        raise ValueError(message)
    if not namespace.isdtype(matrix.dtype, ("real floating", "complex floating")):
        message = "matrix_power requires a floating-point array"
        raise TypeError(message)
    if exponent == 0:
        ones = namespace.ones_like(matrix)
        return namespace.triu(namespace.tril(ones))

    base = namespace.linalg.inv(matrix) if exponent < 0 else matrix
    remaining = abs(exponent)
    result = None
    while remaining:
        if remaining & 1:
            result = base if result is None else namespace.matmul(result, base)
        remaining >>= 1
        if remaining:
            base = namespace.matmul(base, base)
    if result is None:
        message = "matrix_power failed to produce a result"
        raise AssertionError(message)
    return result


def _matrix_rank_composite(namespace: Any, matrix: Any, rtol: Any | None) -> Any:
    shape = tuple(int(size) for size in matrix.shape)
    if len(shape) < _MIN_MATRIX_RANK:
        message = "matrix_rank requires an array with at least two dimensions"
        raise ValueError(message)
    singular_values = namespace.linalg.svdvals(matrix)
    maximum = namespace.max(singular_values, axis=-1, keepdims=True)
    if rtol is None:
        rtol = max(shape[-2:]) * namespace.finfo(matrix.dtype).eps
    if not (hasattr(rtol, "shape") and hasattr(rtol, "dtype")):
        rtol = namespace.asarray(rtol, dtype=singular_values.dtype)
    rtol = namespace.expand_dims(rtol, axis=-1)
    tolerance = namespace.multiply(maximum, rtol)
    rank_mask = namespace.greater(singular_values, tolerance)
    return namespace.sum(namespace.astype(rank_mask, namespace.int64), axis=-1)


def _staged_array_api_composite(  # noqa: C901, PLR0912 - explicit bounded surface
    path: str,
    namespace: Any,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> Any:
    if path == "broadcast_arrays":
        if not args or kwargs:
            message = "broadcast_arrays() expects one or more arrays"
            raise TypeError(message)
        shapes = tuple(tuple(int(size) for size in value.shape) for value in args)
        shape = _broadcast_shape(*shapes)
        return [namespace.broadcast_to(value, shape) for value in args]

    if path == "linalg.matrix_power":
        if len(args) != _BINARY_ARITY or kwargs:
            message = "matrix_power() expects a matrix and a static integer exponent"
            raise TypeError(message)
        return _matrix_power_composite(namespace, args[0], args[1])

    if path == "linalg.matrix_rank":
        if len(args) != 1 or set(kwargs) - {"rtol"}:
            message = "matrix_rank() expects one array and optional keyword-only rtol"
            raise TypeError(message)
        return _matrix_rank_composite(namespace, args[0], kwargs.get("rtol"))

    if path == "meshgrid":
        if not args or set(kwargs) - {"indexing"}:
            message = "meshgrid() expects one or more arrays and optional indexing"
            raise TypeError(message)
        indexing = kwargs.get("indexing", "xy")
        if indexing not in {"ij", "xy"}:
            message = "meshgrid indexing must be 'ij' or 'xy'"
            raise ValueError(message)
        if any(len(value.shape) != 1 for value in args):
            message = "meshgrid inputs must be one-dimensional"
            raise ValueError(message)
        if any(value.dtype != args[0].dtype for value in args[1:]):
            message = "meshgrid inputs must all have the same dtype"
            raise ValueError(message)
        if any(value.device != args[0].device for value in args[1:]):
            message = "meshgrid inputs must all be on the same device"
            raise ValueError(message)
        sizes = tuple(int(value.shape[0]) for value in args)
        rank = len(args)
        axes = list(range(rank))
        if indexing == "xy" and rank >= _BINARY_ARITY:
            axes[0], axes[1] = axes[1], axes[0]
        target = tuple(sizes[index] for index in axes)
        outputs = []
        for position, value in enumerate(args):
            shape = tuple(
                sizes[position] if dimension == axes[position] else 1 for dimension in range(rank)
            )
            reshaped = namespace.reshape(value, shape)
            outputs.append(namespace.broadcast_to(reshaped, target))
        return outputs

    if path == "unstack":
        if len(args) != 1 or set(kwargs) - {"axis"}:
            message = "unstack() expects one array and optional keyword-only axis"
            raise TypeError(message)
        value = args[0]
        rank = len(value.shape)
        axis_value = kwargs.get("axis", 0)
        axis = _normalize_axis(axis_value, rank)
        return tuple(
            value[tuple(index if dimension == axis else slice(None) for dimension in range(rank))]
            for index in range(int(value.shape[axis]))
        )

    message = f"Unknown staged Array API composite {path!r}"
    raise AssertionError(message)


_CUMULATIVE_IDENTITIES = {"cumulative_prod": 1, "cumulative_sum": 0}


def _cumulative_with_initial(
    path: str,
    namespace: Any,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> Any:
    if len(args) != 1:
        message = f"{path}() expects one positional array argument"
        raise TypeError(message)
    source = args[0]
    options = dict(kwargs)
    del options["include_initial"]
    rank = len(source.shape)
    axis_value = options.get("axis")
    if axis_value is None and rank != 1:
        message = "cumulative operations require axis= for inputs with more than one dimension"
        raise ValueError(message)
    axis = 0 if axis_value is None else _normalize_axis(axis_value, rank)
    base = getattr(namespace, path)(source, **{**options, "axis": axis})
    seed_shape = list(base.shape)
    seed_shape[axis] = 1
    seed = namespace.full(tuple(seed_shape), _CUMULATIVE_IDENTITIES[path], dtype=base.dtype)
    return namespace.concat((seed, base), axis=axis)


def _diff_with_boundaries(
    namespace: Any,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> Any:
    if len(args) != 1:
        message = "diff() expects one positional array argument"
        raise TypeError(message)
    source = args[0]
    options = dict(kwargs)
    prepend = options.pop("prepend", None)
    append = options.pop("append", None)
    if (prepend is None and append is None) or options.get("n", 1) == 0:
        return namespace.diff(source, **options)
    axis = _normalize_axis(options.get("axis", -1), len(source.shape))
    boundary_shape = list(source.shape)
    boundary_shape[axis] = 1

    def boundary(value: Any) -> Any:
        # Scalars and rank-zero arrays broadcast across the boundary slice.
        if getattr(value, "shape", ()) != ():
            return value
        return namespace.full(tuple(boundary_shape), value)

    parts = (
        *(() if prepend is None else (boundary(prepend),)),
        source,
        *(() if append is None else (boundary(append),)),
    )
    return namespace.diff(namespace.concat(parts, axis=axis), **options)


def _searchsorted_with_sorter(
    namespace: Any,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> Any:
    if len(args) != _BINARY_ARITY:
        message = "searchsorted() expects two positional array arguments"
        raise TypeError(message)
    options = dict(kwargs)
    sorted_source = namespace.take(args[0], options.pop("sorter"), axis=0)
    return namespace.searchsorted(sorted_source, args[1], **options)


def lower_array_api_call(
    path: str,
    namespace: Any,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> Any:
    """Lower a standard form that has no single canonical operation.

    The dynamic proxy and the abstract namespace both pass themselves, so each
    lowered step records through that frontend's ordinary namespace calls.
    Return ``NotImplemented`` when the call binds to one canonical operation.
    """
    if path in _CUMULATIVE_IDENTITIES and kwargs.get("include_initial"):
        return _cumulative_with_initial(path, namespace, args, kwargs)
    if path == "diff" and ("prepend" in kwargs or "append" in kwargs):
        return _diff_with_boundaries(namespace, args, kwargs)
    if path == "searchsorted" and kwargs.get("sorter") is not None:
        return _searchsorted_with_sorter(namespace, args, kwargs)
    return NotImplemented


class ArrayAPINamespace:
    """Trace-aware proxy for one concrete Python Array API namespace."""

    __slots__ = (
        "_array_api_version",
        "_namespace",
        "_nests_in_stage",
        "_path",
        "_profile",
        "_root_namespace",
    )

    def __init__(
        self,
        namespace: Any,
        *,
        path: str = "",
        root_namespace: Any | None = None,
        array_api_version: str = LATEST_ARRAY_API_VERSION,
    ) -> None:
        self._namespace = namespace
        self._path = path
        self._root_namespace = namespace if root_namespace is None else root_namespace
        self._array_api_version = array_api_version
        self._profile = materialize_array_api_profile(array_api_version)
        # A dynamic trace inside a stage wraps abstract staged values.
        self._nests_in_stage = (
            getattr(self.raw_namespace, "__name__", "") == ABSTRACT_NAMESPACE_NAME
        )

    @property
    def __name__(self) -> str:
        return cast("str", getattr(self._namespace, "__name__", type(self._namespace).__name__))

    @property
    def __array_api_version__(self) -> str:
        return self._array_api_version

    @property
    def raw_namespace(self) -> Any:
        """Return the provider namespace used for concrete execution."""
        root = self._root_namespace
        return root.raw_namespace if isinstance(root, ArrayAPINamespace) else root

    def __array_namespace_info__(self) -> Any:
        return self.raw_namespace.__array_namespace_info__()

    def _advect_materialize_constant(self, value: object, spec: Any) -> Any:
        """Lift a provider constant through a nested dynamic trace.

        An outer abstract namespace may own a durable constant; a concrete
        provider can use the value directly. In both cases the temporary
        ``advect.const`` node gives the inner dynamic tape a dispatch identity
        without making the constant a differentiated input.
        """
        if bool(getattr(type(value), "__advect_abstract_array__", False)):
            materialized = value
        else:
            raw_namespace = self.raw_namespace
            materialize = getattr(raw_namespace, "_advect_materialize_constant", None)
            materialized = materialize(value, spec) if callable(materialize) else value
            if materialized is NotImplemented:
                materialized = value
        recorder = _get_active_recorder()
        if recorder is None or not (
            hasattr(materialized, "shape") and hasattr(materialized, "dtype")
        ):
            return materialized
        constant_value = cast("Any", materialized)
        node_id = recorder.record_operation(
            "advect.const",
            (),
            constant_value,
            {},
            tuple(int(dimension) for dimension in constant_value.shape),
            constant_value.dtype,
        )
        raw_namespace = self.raw_namespace
        return ArrayAPITracer(
            constant_value,
            node_id,
            cast("DynamicTape", recorder),
            namespace=raw_namespace,
            array_api_version=self._array_api_version,
            owned=False,
        )

    def __getattr__(self, name: str) -> Any:
        path = f"{self._path}.{name}" if self._path else name
        known_path = path in OFFICIAL_SIGNATURES
        if known_path and not self._profile.admits(path):
            message = (
                f"Array API function {path!r} is not available in the selected "
                f"{self._array_api_version} revision"
            )
            raise AttributeError(message)
        value = getattr(self._namespace, name)
        if not self._path and name in {"fft", "linalg"}:
            return ArrayAPINamespace(
                value,
                path=path,
                root_namespace=self.raw_namespace,
                array_api_version=self._array_api_version,
            )
        if callable(value):
            # A nested proxy's value already calls through its parent proxy.
            return partial(self._call, path, value)
        return value

    def __dir__(self) -> list[str]:
        prefix = f"{self._path}." if self._path else ""
        return sorted(
            name
            for name in set(super().__dir__()) | set(dir(self._namespace))
            if f"{prefix}{name}" not in OFFICIAL_SIGNATURES
            or self._profile.admits(f"{prefix}{name}")
        )

    def _asarray_live_sequence(
        self,
        function: Callable[..., Any],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Any:
        if len(args) != 1 or not isinstance(args[0], (tuple, list)):
            message = "asarray() expects one positional object argument"
            raise TypeError(message)
        if kwargs.get("copy") is False:
            message = "asarray(copy=False) cannot construct an array from a sequence"
            raise ValueError(message)

        def build(value: Any) -> Any:
            if isinstance(value, ArrayAPITracer):
                return value
            if isinstance(value, (tuple, list)):
                if not value:
                    return self.raw_namespace.asarray(value)
                children = tuple(build(item) for item in value)
                stack = cast("Callable[..., Any]", self.raw_namespace.stack)
                return self._call("stack", stack, children, axis=0)
            return self.raw_namespace.asarray(value)

        assembled = build(args[0])
        return self._call("asarray", function, assembled, **kwargs)

    def _composite_namespace(
        self,
        tracers: tuple[ArrayAPITracer, ...],
        *,
        path: str,
    ) -> ArrayAPINamespace:
        for tracer in tracers:
            tracer._require_active_recorder()  # noqa: SLF001 - same frontend invariant
            if not _same_namespace(tracer.raw_namespace, self.raw_namespace):
                message = f"Cannot combine different Array API namespaces in {path}()"
                raise TypeError(message)
        return ArrayAPINamespace(
            self.raw_namespace,
            array_api_version=self._array_api_version,
        )

    def _dynamic_array_api_composite(
        self,
        path: str,
        namespace: ArrayAPINamespace,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Any:
        if len(args) != 1 or kwargs:
            message = f"{path}() expects one positional array argument"
            raise TypeError(message)
        source = args[0]
        raw_source = _unwrap(source)
        raw_function = getattr(self.raw_namespace, path)

        if path == "nonzero":
            result = raw_function(raw_source)
            return tuple(namespace._advect_materialize_constant(value, None) for value in result)

        all_result = self.raw_namespace.unique_all(raw_source)
        flattened = namespace.reshape(source, (-1,))
        values = namespace.take(flattened, all_result.indices, axis=0)
        if path == "unique_values":
            return values

        if path == "unique_all":
            result = all_result
            metadata = result[1:]
        elif path == "unique_counts":
            result = raw_function(raw_source)
            metadata = (all_result.counts,)
        elif path == "unique_inverse":
            result = raw_function(raw_source)
            metadata = (all_result.inverse_indices,)
        else:
            message = f"Unknown dynamic Array API composite {path!r}"
            raise AssertionError(message)
        return type(result)(
            values,
            *(namespace._advect_materialize_constant(value, None) for value in metadata),
        )

    def _advect_python_operator(self, path: str, operands: tuple[Any, ...]) -> Any:
        """Apply Python's operator to weak operands and record a weak result (NEP 50).

        A standard function would require an array operand.
        """
        binding = bind_array_api_call(path, operands, {})
        operator = cast("Callable[..., Any]", python_operator(binding.op, len(operands)))
        tracers = [operand for operand in operands if isinstance(operand, ArrayAPITracer)]
        for tracer in tracers:
            tracer._require_active_recorder()  # noqa: SLF001 - same frontend invariant
        value = operator(*_unwrap(operands))
        if type(value) in PYTHON_SCALAR_TYPES:
            value = self.raw_namespace.asarray(value)
        (result,) = self._record(
            binding, _recording_targets(tracers), (value,), (((), value.dtype),), weak=True
        )
        return result

    def _record(
        self,
        binding: ArrayAPICallBinding,
        targets: tuple[DynamicTape, ...],
        outputs: tuple[Any, ...],
        metadata: tuple[tuple[tuple[int, ...], Any], ...],
        *,
        weak: bool = False,
    ) -> tuple[Any, ...]:
        """Record one bound call on each target recorder, outermost first."""
        attrs = dict(binding.attrs)
        backend = _get_backend_key_from_namespace(self.raw_namespace)
        if backend is not None:
            attrs["_advect_backend"] = backend
        attrs["_advect_array_api_version"] = self._array_api_version
        result_value: Any = outputs
        for target_recorder in targets:
            result_value = _record_array_api_result(
                recorder=target_recorder,
                binding=binding,
                values=cast("tuple[Any, ...]", result_value),
                attrs=attrs,
                metadata=metadata,
                namespace=self.raw_namespace,
                array_api_version=self._array_api_version,
                weak=weak,
            )
            if binding.num_outputs == 1:
                result_value = (result_value,)
        return cast("tuple[Any, ...]", result_value)

    def _call(  # noqa: PLR0911 - one closed frontend dispatch
        self,
        path: str,
        function: Callable[..., Any],
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        args, kwargs = _normalize_provider_call(path, args, kwargs)
        kwargs = _normalize_accumulation_dtype(
            path,
            args,
            kwargs,
            namespace=self.raw_namespace,
            array_api_version=self._array_api_version,
        )
        if self._nests_in_stage:
            args, kwargs = _as_array_api_nested((args, kwargs), self)
        if path in _ARRAY_API_META_FUNCTIONS:
            return function(
                *cast("tuple[Any, ...]", _unwrap(args)),
                **cast("dict[str, Any]", _unwrap(kwargs)),
            )
        call_tracers = (*_array_api_tracers(args), *_array_api_tracers(kwargs))
        if not call_tracers:
            return function(*args, **kwargs)
        if path in _ARRAY_API_COMPOSITES:
            namespace = self._composite_namespace(call_tracers, path=path)
            if path in _STAGED_ARRAY_API_COMPOSITES:
                return _staged_array_api_composite(path, namespace, args, kwargs)
            return self._dynamic_array_api_composite(path, namespace, args, kwargs)
        if path == "asarray" and isinstance(args[0] if args else None, (tuple, list)):
            return self._asarray_live_sequence(function, args, kwargs)
        lowered = lower_array_api_call(path, self, args, kwargs)
        if lowered is not NotImplemented:
            return lowered
        binding = bind_array_api_call(path, args, kwargs)
        tracers = [operand for operand in binding.operands if isinstance(operand, ArrayAPITracer)]
        if not tracers:
            return function(*args, **kwargs)
        if binding.op in PYTHON_ATTRIBUTE_OPS and all(
            literal_is_weak(operand) for operand in binding.operands
        ):
            # NumPy's real() and imag() read the attribute, which keeps a weak scalar weak.
            return self._advect_python_operator(path, binding.operands)

        root_namespace = self.raw_namespace
        for tracer in tracers:
            tracer._require_active_recorder()  # noqa: SLF001 - same frontend invariant
            if not _same_namespace(tracer._namespace, root_namespace):  # noqa: SLF001
                msg = f"Cannot combine different Array API namespaces in {path}()"
                raise TypeError(msg)
        targets = _recording_targets(tracers)

        concrete_args = cast("tuple[Any, ...]", _unwrap(args))
        concrete_kwargs = cast("dict[str, Any]", _unwrap(kwargs))
        concrete_args = cast(
            "tuple[Any, ...]",
            materialize_weak_scalar_operands(
                binding.op,
                concrete_args,
                namespace=root_namespace,
            ),
        )
        result = function(*concrete_args, **concrete_kwargs)
        outputs, output_metadata = _normalize_array_api_outputs(
            path,
            result,
            num_outputs=binding.num_outputs,
        )

        result_value = self._record(binding, targets, outputs, output_metadata)
        if binding.num_outputs == 1:
            return result_value[0]
        return restore_array_api_result(path, result_value)


class ArrayAPITracer:
    """Concrete traced value for non-NumPy Python Array API arrays."""

    __slots__ = (
        "_array_api_version",
        "_namespace",
        "_namespace_proxy",
        "_node_id",
        "_owned",
        "_recorder",
        "_value",
    )

    __array_priority__ = 100_000
    __advect_namespace_is_instance_specific__ = True
    # Elementwise `__eq__` is installed below; keep tracers unhashable.
    __hash__: ClassVar[None] = None

    def __init__(
        self,
        value: Any,
        node_id: int,
        recorder: DynamicTape,
        *,
        namespace: Any,
        array_api_version: str,
        owned: bool = True,
    ) -> None:
        self._value = value
        self._node_id = node_id
        self._recorder = recorder
        self._namespace = namespace
        self._array_api_version = array_api_version
        self._namespace_proxy: ArrayAPINamespace | None = None
        self._owned = owned

    @property
    def recorder(self) -> DynamicTape:
        """Return the invocation recorder that owns this SSA value."""
        return self._recorder

    def _require_active_recorder(self) -> DynamicTape:
        if not _is_recorder_in_active_trace_stack(self._recorder):
            msg = (
                "This Array API tracer escaped the trace that created it. "
                "Return concrete values from the transform instead of retaining tracers."
            )
            raise EscapedTracerError(msg)
        return self._recorder

    @property
    def value(self) -> Any:
        """Reject public access to the trace-time payload."""
        msg = (
            "Tracer payloads are private Advect implementation details. "
            "Return a value from the traced function to materialize it."
        )
        raise TracingError(msg)

    def _advect_snapshot(self) -> tuple[int, Any]:
        """Return one internally validated SSA/value pair."""
        self._require_active_recorder()
        return self._node_id, self._value

    def _advect_adopt(self, value: Any) -> Any:
        """Rewrap another frontend's tracer on this tape as an Array API tracer."""
        if (
            isinstance(value, ArrayAPITracer)
            or getattr(value, "recorder", None) is not self._recorder
        ):
            return value
        node_id, payload = _snapshot_traced(value)
        return ArrayAPITracer(
            payload,
            node_id,
            self._recorder,
            namespace=self._namespace,
            array_api_version=self._array_api_version,
        )

    @property
    def node_id(self) -> int:
        self._require_active_recorder()
        return self._node_id

    @property
    def raw_namespace(self) -> Any:
        self._require_active_recorder()
        return self._namespace

    @property
    def shape(self) -> tuple[int, ...]:
        self._require_active_recorder()
        return tuple(int(dimension) for dimension in self._value.shape)

    @property
    def dtype(self) -> Any:
        self._require_active_recorder()
        return self._value.dtype

    @property
    def _advect_weak(self) -> bool:
        """Return the weak-scalar category of the current SSA value."""
        return self._require_active_recorder().is_weak(self._node_id)

    def _advect_mark_weak(self) -> None:
        """Mark this rank-zero SSA value as a weak scalar."""
        self._require_active_recorder().mark_weak(self._node_id)

    def __repr__(self) -> str:
        """Return a compact trace identity or a bounded debug payload summary."""
        self._require_active_recorder()
        prefix = f"ArrayAPITracer(node=%{self._node_id}"
        if is_debug():
            return f"{prefix}, {summarize_value(self._value)})"
        return f"{prefix}, shape={self.shape}, dtype={self.dtype})"

    @property
    def ndim(self) -> int:
        return len(self.shape)

    @property
    def size(self) -> int:
        return math.prod(self.shape)

    @property
    def device(self) -> Any:
        self._require_active_recorder()
        return getattr(self._value, "device", None)

    def __array_namespace__(self, *, api_version: str | None = None) -> ArrayAPINamespace:
        self._require_active_recorder()
        current = self._array_api_version
        if api_version is not None and api_version != current:
            msg = f"Array API version {api_version!r} requested, but provider exposes {current!r}"
            raise ValueError(msg)
        if self._namespace_proxy is None:
            self._namespace_proxy = ArrayAPINamespace(self._namespace, array_api_version=current)
        return self._namespace_proxy

    def __array_ufunc__(
        self,
        ufunc: Any,
        method: str,
        *inputs: Any,
        **kwargs: Any,
    ) -> Any:
        """Offer a foreign array protocol to its registered frontend."""
        from advect.core._backends import get_hook  # noqa: PLC0415 - avoid import cycle

        handler = get_hook("advect.foreign_array_ufunc")
        if handler is None:
            return NotImplemented
        return handler(self, ufunc, method, inputs, kwargs)

    def __array_function__(
        self,
        function: Any,
        types: tuple[type, ...],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Any:
        """Offer a foreign array-function protocol to its registered frontend."""
        del types
        from advect.core._backends import get_hook  # noqa: PLC0415 - avoid import cycle

        handler = get_hook("advect.foreign_array_function")
        if handler is None:
            return NotImplemented
        return handler(self, function, args, kwargs)

    def __array__(self, dtype: Any | None = None, copy: bool | None = None) -> Any:
        del dtype, copy
        raise TracingError(_array_conversion_error())

    def __bool__(self) -> bool:
        self._require_active_recorder()
        return bool(self._value)

    def __len__(self) -> int:
        self._require_active_recorder()
        if not self.shape:
            msg = "len() of a 0-dimensional array"
            raise TypeError(msg)
        return self.shape[0]

    def __iter__(self) -> Any:
        return (self[index] for index in range(len(self)))

    def __getitem__(self, index: Any) -> ArrayAPITracer:
        recorder = self._require_active_recorder()
        # A traced index array selects by its concrete values, which carry no
        # derivative; providers also reject a tracer inside an index.
        index = _unwrap(index)
        result = self._value[index]
        node_id = recorder.record_operation(
            "advect.getitem",
            (self.node_id,),
            result,
            {
                "index": index,
                "_advect_backend": _get_backend_key_from_namespace(self._namespace),
            },
            tuple(int(dimension) for dimension in result.shape),
            result.dtype,
        )
        return ArrayAPITracer(
            result,
            node_id,
            recorder,
            namespace=self._namespace,
            array_api_version=self._array_api_version,
            owned=False,
        )

    def __setitem__(self, index: Any, value: Any) -> None:
        recorder = self._require_active_recorder()
        if not self._owned:
            msg = (
                "Mutation for generic Array API inputs is not supported. "
                "Copy the value before applying an internal functional update."
            )
            raise MutationError(msg)
        index = _unwrap(index)
        source_id, source_value = self._advect_snapshot()
        replacement_id, replacement_value = _operand_for_recorder(value, recorder=recorder)
        result = _copy_array_value(source_value, self._namespace)
        result[index] = replacement_value
        literal = replacement_id is None
        self._node_id = recorder.record_operation(
            "advect.index_update",
            (source_id,) if literal else (source_id, replacement_id),
            result,
            {"index": index, "mode": "set"},
            tuple(int(dimension) for dimension in result.shape),
            result.dtype,
            input_positions=(0,) if literal else None,
            literals=(replacement_value,) if literal else (),
        )
        self._value = result

    def copy(self) -> ArrayAPITracer:
        """Record an owned copy for staged graph replay."""
        recorder = self._require_active_recorder()
        source_id, source_value = self._advect_snapshot()
        result = _copy_array_value(source_value, self._namespace)
        node_id = recorder.record_operation(
            "advect.copy",
            (source_id,),
            result,
            {},
            tuple(int(dimension) for dimension in result.shape),
            result.dtype,
        )
        return ArrayAPITracer(
            result,
            node_id,
            recorder,
            namespace=self._namespace,
            array_api_version=self._array_api_version,
            owned=True,
        )

    def astype(
        self,
        dtype: Any,
        *,
        copy: bool = True,
        device: Any | None = None,
    ) -> ArrayAPITracer:
        namespace = self.__array_namespace__()
        kwargs: dict[str, Any] = {"copy": copy}
        if device is not None:
            kwargs["device"] = device
        return cast("ArrayAPITracer", namespace.astype(self, dtype, **kwargs))

    def reshape(self, *shape: Any) -> ArrayAPITracer:
        target = shape[0] if len(shape) == 1 and isinstance(shape[0], tuple) else tuple(shape)
        return cast("ArrayAPITracer", self.__array_namespace__().reshape(self, target))

    def item(self, *args: object) -> ArrayAPITracer:
        """Return one element as a rank-zero traced value."""
        return cast("ArrayAPITracer", select_item(self, args))

    def sum(self, *, axis: Any = None, dtype: Any = None, keepdims: bool = False) -> Any:
        kwargs: dict[str, Any] = {"axis": axis, "keepdims": keepdims}
        if dtype is not None:
            kwargs["dtype"] = dtype
        return self.__array_namespace__().sum(self, **kwargs)

    def conj(self) -> ArrayAPITracer:
        return cast("ArrayAPITracer", self.__array_namespace__().conj(self))

    @property
    def real(self) -> ArrayAPITracer:
        return cast("ArrayAPITracer", self._unary("real"))

    @property
    def imag(self) -> ArrayAPITracer:
        return cast("ArrayAPITracer", self._unary("imag"))

    @property
    def T(self) -> ArrayAPITracer:  # noqa: N802 - standard array spelling
        axes = tuple(reversed(range(self.ndim)))
        return cast("ArrayAPITracer", self.__array_namespace__().permute_dims(self, axes))

    @property
    def mT(self) -> ArrayAPITracer:  # noqa: N802 - standard array spelling
        return cast("ArrayAPITracer", self.__array_namespace__().matrix_transpose(self))

    def _binary(self, name: str, other: Any, *, reverse: bool = False) -> Any:
        if bool(getattr(type(self._value), "__advect_abstract_array__", False)):
            if getattr(type(other), "__advect_frontend__", None) is not None:
                return NotImplemented
            # The staged value's frontend decides whether ``**`` squares, as
            # NumPy squares a boolean array to int8 where its power gives int64.
            if name == "pow" and not reverse and self._value._squares(other):  # noqa: SLF001
                return self.__array_namespace__().square(self)
        namespace = self.__array_namespace__()
        operands = (other, self) if reverse else (self, other)
        # Python's operator on Python scalars keeps a weak result (NEP 50).
        if self.shape == () and all(literal_is_weak(operand) for operand in operands):
            return namespace._advect_python_operator(name, operands)  # noqa: SLF001
        return getattr(namespace, name)(*operands)

    def _unary(self, name: str) -> Any:
        namespace = self.__array_namespace__()
        if self.shape == () and self._advect_weak:
            return namespace._advect_python_operator(name, (self,))  # noqa: SLF001
        return getattr(namespace, name)(self)

    def __neg__(self) -> Any:
        return self._unary("negative")

    def __pos__(self) -> Any:
        return self._unary("positive")

    def __abs__(self) -> Any:
        return self._unary("abs")

    def __invert__(self) -> Any:
        return self._unary("bitwise_invert")


def _tracer_operator(
    function: str, *, reverse: bool = False
) -> Callable[[ArrayAPITracer, Any], Any]:
    def operator(self: ArrayAPITracer, other: Any) -> Any:
        return self._binary(function, other, reverse=reverse)

    return operator


for _stem, _function in _ARITHMETIC_OPERATORS.items():
    setattr(ArrayAPITracer, f"__{_stem}__", _tracer_operator(_function))
    setattr(ArrayAPITracer, f"__r{_stem}__", _tracer_operator(_function, reverse=True))
for _stem, _function in _COMPARISON_OPERATORS.items():
    setattr(ArrayAPITracer, f"__{_stem}__", _tracer_operator(_function))
