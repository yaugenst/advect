"""Scalar output helpers shared by reverse-mode API entrypoints."""

from __future__ import annotations

from typing import TYPE_CHECKING

from advect.autodiff.api._pullback_values import _ones_like, _provider_scalar_like
from advect.autodiff.api._scalar_boundary import _is_real_python_scalar
from advect.core._pytree import tree_flatten, tree_unflatten

if TYPE_CHECKING:
    from advect.core._pytree import TreeDef


def _is_scalar_value(value: object) -> bool:
    """Recognize concrete Python scalar values."""
    return _is_real_python_scalar(value) or type(value) is complex


def _scalar_cotangent_for_output(
    *,
    out_leaf: object,
    out_treedef: TreeDef,
) -> object:
    g_leaf = _scalar_cotangent_leaf(out_leaf)
    if out_treedef.node_type is None:
        return g_leaf
    return tree_unflatten(out_treedef, [g_leaf])


def _scalar_cotangent_leaf(out_leaf: object) -> object:
    """Construct the scalar seed without rebuilding output pytree structure."""
    if _is_scalar_value(out_leaf):
        return 1.0
    if getattr(out_leaf, "shape", None) == ():
        staged_seed = getattr(out_leaf, "_advect_scalar_cotangent", None)
        if callable(staged_seed):
            return staged_seed()
        seed = _provider_scalar_like(out_leaf, 1)
        if seed is not None:
            return seed
    return _ones_like(out_leaf)


def _extract_scalar_output(value: object, *, transform_name: str) -> tuple[object, TreeDef]:
    leaves, out_treedef = tree_flatten(value)
    if out_treedef.node_type is None:
        out_leaf = value
    else:
        if len(leaves) != 1:
            msg = (
                f"{transform_name} requires a scalar-valued function, but output pytree has "
                f"{len(leaves)} leaves. "
                "Use vjp() for non-scalar outputs, or reduce your output to a scalar."
            )
            raise ValueError(msg)
        out_leaf = leaves[0]

    is_scalar = (
        _is_scalar_value(out_leaf)
        or (hasattr(out_leaf, "shape") and out_leaf.shape == ())
        or (hasattr(out_leaf, "ndim") and out_leaf.ndim == 0)
    )
    if not is_scalar:
        shape = getattr(out_leaf, "shape", "unknown")
        msg = (
            f"{transform_name} requires a scalar-valued function, but output has shape {shape}. "
            "Use vjp() for non-scalar outputs, or reduce your output to a scalar."
        )
        raise ValueError(msg)
    return out_leaf, out_treedef
